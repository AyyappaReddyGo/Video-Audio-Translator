package com.example.videotranslation;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

@RestController
public class TranslationController {

    private static final String API_KEY = System.getenv("API_KEY");

    @GetMapping("/")
    public String home() {
        return "Video Translation API is running";
    }

    @PostMapping("/translate")
    public ResponseEntity<?> translateVideo(
            @RequestHeader(value = "x-api-key", required = false) String apiKey,
            @RequestParam("video") MultipartFile video,
            @RequestParam("source_language") String sourceLang,
            @RequestParam("target_language") String targetLang) {

        if (apiKey == null || !apiKey.equals(API_KEY)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid or missing API key");
        }

        try {
            Path videoPath = Files.createTempFile("video_", ".mp4");
            video.transferTo(videoPath.toFile());

            // NOTE:
            // Actual speech recognition, translation, and TTS
            // would require external APIs or services in Java.
            // This implementation demonstrates backend structure.

            return ResponseEntity.ok("Video received and processed successfully");

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(e.getMessage());
        }
    }
}
